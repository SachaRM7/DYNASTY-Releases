import { prepareJ4Communication, finishJ4Communication } from '../../web/scripts/j4-journey.mjs';
import { enterProto2, prepareProto2Delivery, finishProto2Delivery, proto2State } from '../../web/scripts/proto2-journey.mjs';
import { checkResourceLayers } from '../../web/scripts/j3-5-hud-journey.mjs';
// Windows-only end-to-end test. Launches the NSIS portable stub itself, never win-unpacked.
import assert from 'node:assert/strict';
import { prepareJ3Mission, finishJ3Mission, j3State } from '../../web/scripts/j3-journey.mjs';
import { createRequire } from 'node:module';
import { spawn, execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { once } from 'node:events';
import { createServer } from 'node:net';
import { mkdir, copyFile, readFile, writeFile, access } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

if (process.platform !== 'win32') throw new Error('Ce test exige Windows et les exécutables construits.');
if (!process.env.CI) throw new Error('Ce test utilise le profil par défaut : réservé à un runner CI Windows jetable.');
const { chromium, _electron, expect } = createRequire(new URL('../../web/package.json', import.meta.url))('@playwright/test');
const { verifySignature } = createRequire(import.meta.url)('../updater.cjs');
const desktop = fileURLToPath(new URL('../', import.meta.url));
const root = fileURLToPath(new URL('../../../', import.meta.url));
const {version}=JSON.parse(await readFile(path.join(desktop,'package.json'),'utf8'));
const fixtureVersion='0.6.1';
const report = path.join(root, 'reports', 'proto2', 'windows');
const profile = path.join(process.env.APPDATA, 'DYNASTY-Prototype');
const installDir = path.join(process.env.LOCALAPPDATA, 'Programs', 'dynasty-desktop');
const installedExe = path.join(installDir, 'DYNASTY.exe');
const shortcut = path.join(process.env.APPDATA, 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'DYNASTY.lnk');
const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
const exec = promisify(execFile);
const env = { ...process.env }; delete env.ELECTRON_RUN_AS_NODE;
const evidence = { platform: process.platform, sha: process.env.DYNASTY_SOURCE_SHA ?? process.env.GITHUB_SHA, profile: '%APPDATA%\\DYNASTY-Prototype', origin: 'dynasty://game/', steps: [], errors: [] };
await mkdir(report, { recursive: true });
// Refuse to overwrite any pre-existing save, even on a misconfigured CI runner.
await assert.rejects(access(path.join(profile, 'Local Storage')), /ENOENT/);
let running;
async function record(name, details = {}) {
  evidence.steps.push({ name, ...details });
  await writeFile(path.join(report, 'results.json'), JSON.stringify(evidence, null, 2));
  console.log(`PASS ${name}`);
}
async function launch(executable, portable = false, overrideProfile) {
  const errors = evidence.errors;
  let page, close, application;
  if (portable) {
    const server = createServer(); server.listen(0, '127.0.0.1'); await once(server, 'listening');
    const port = server.address().port; await new Promise(resolve => server.close(resolve));
    const child = spawn(executable, [`--remote-debugging-port=${port}`, '--disable-gpu', ...(overrideProfile ? [`--user-data-dir=${overrideProfile}`] : [])], { env, stdio: 'ignore' });
    let childError; child.on('error', error => { childError = error; });
    let connected;
    for (let i = 0; i < 900; i++) {
      if (childError) throw childError;
      if (child.exitCode !== null) throw new Error(`Portable terminé avant démarrage : ${child.exitCode}`);
      try {
        const response = await fetch(`http://127.0.0.1:${port}/json/version`);
        if (response.ok) { connected = true; break; }
      } catch { /* extraction/startup still in progress */ }
      await wait(100);
    }
    assert.ok(connected, 'Le véritable Portable doit lancer son Electron');
    const browser = await chromium.connectOverCDP(`http://127.0.0.1:${port}`);
    const context = browser.contexts()[0];
    page = context.pages()[0] ?? await context.waitForEvent('page');
    close = async () => {
      // Closing the window also lets the NSIS bootstrap finish cleaning its temp folder.
      const cdp = await context.newCDPSession(page);
      const { targetInfo } = await cdp.send('Target.getTargetInfo');
      await cdp.send('Target.closeTarget', { targetId: targetInfo.targetId }).catch(() => {});
      for (let i = 0; i < 300 && child.exitCode === null; i++) await wait(100);
      assert.equal(child.exitCode, 0, 'Fermeture propre du Portable et vidage du stockage');
      await browser.close();
    };
  } else {
    application = await _electron.launch({ executablePath: executable, args: ['--disable-gpu'], env, timeout: 60000 });
    page = await application.firstWindow();
    close = () => application.close();
    const actual = await application.evaluate(({ app }) => ({ profile: app.getPath('userData'), packaged: app.isPackaged, version: app.getVersion() }));
    assert.equal(actual.profile.toLowerCase(), profile.toLowerCase()); assert.equal(actual.packaged, true);
    await record('Installed runtime', { version: actual.version });
  }
  running = { page, close, application };
  page.on('pageerror', error => errors.push(error.message));
  await page.getByRole('navigation').waitFor({ timeout: 60000 });
  assert.equal(page.url(), 'dynasty://game/');
  assert.deepEqual(await page.evaluate(() => [typeof window.require, typeof window.process]), ['undefined', 'undefined']);
  return page;
}
async function stop() { await running.close(); running = null; }
async function nav(page, name) { await page.getByRole('navigation').getByRole('button', { name, exact: true }).click(); }
async function checkAdjustedHud(page, distribution) {
  await expect(page.locator('.hud-identity')).toHaveText('');
  await page.getByRole('button', { name: 'Ouvrir la fiche : Étienne Garnier', exact: true }).click();
  await expect(page.locator('#side-panel h2')).toHaveText('Étienne Garnier');
  await expect(page.getByTestId('hud-news').locator('.news-type, .news-source')).toHaveCount(0);
  await record(`${distribution}: clickable portrait, no permanent caption, compact news`);
}
async function population(page) {
  await nav(page, 'Carnet'); await page.getByRole('tab', { name: 'Personnes', exact: true }).click();
  await page.getByRole('button', { name: 'Collectif et contacts', exact: true }).click();
}
let currentSaveVersion = 3;
async function saved(page, version = currentSaveVersion) {
  await nav(page, 'Agenda'); // ensure the migrated state has been persisted by a real UI command
  const raw = await page.evaluate(version => localStorage.getItem(`dynasty:auto:v${version}`), version);
  assert.ok(raw); return JSON.parse(raw);
}
function stateDigest(state) { return createHash('sha256').update(JSON.stringify(state)).digest('hex'); }
async function assertSame(page, before, label) {
  const after = await saved(page);
  assert.deepEqual(after.state, before.state, label);
  await expect(page.getByTestId('clock')).toContainText('EN PAUSE');
  await record(label, { stateSHA256: stateDigest(after.state), minute: after.state.world.minute });
}
async function install(executable) {
  // /D is the last argument and must not have embedded quotes (NSIS syntax).
  const child = spawn(executable, ['/S', `/D=${installDir}`], { env, stdio: 'ignore' });
  const [code] = await once(child, 'exit'); assert.equal(code, 0, 'NSIS doit réussir sans désinstallation manuelle');
  await access(installedExe); await access(shortcut);
  const { stdout } = await exec('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command',
    // NSIS displays 'DYNASTY <version>' and stores InstallLocation under Software/<GUID>.
    "Get-ItemProperty 'HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*' | Where-Object { $_.DisplayName -match '^DYNASTY(?: |$)' } | ForEach-Object { [PSCustomObject]@{ DisplayVersion=$_.DisplayVersion; RegistryKey=$_.PSChildName; InstallLocation=(Get-ItemProperty -LiteralPath ('HKCU:\\Software\\'+$_.PSChildName)).InstallLocation; MachineInstall=(Test-Path ('HKLM:\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\'+$_.PSChildName)) } } | ConvertTo-Json -Compress"]);
  assert.ok(stdout.trim(), 'Inscription NSIS attendue dans HKCU');
  const entry = JSON.parse(stdout.trim()); assert.ok(!Array.isArray(entry), 'Une seule installation utilisateur');
  assert.equal(entry.MachineInstall, false, 'Aucune installation globale');
  assert.equal(path.resolve(entry.InstallLocation).toLowerCase(), path.resolve(installDir).toLowerCase());
  await record('NSIS current-user installation and Start Menu shortcut', entry);
  return entry;
}
try {
  const historical = path.resolve(process.env.DYNASTY_J1_EXE ?? path.join(root, 'historical-j1', 'prototype', 'desktop', 'dist', 'DYNASTY-0.2.0-Windows-x64.exe'));
  let page = await launch(historical, true);
  await nav(page, 'Agenda'); await page.getByRole('button', { name: 'Avancer de 24 heures', exact: true }).click();
  await population(page); await page.getByRole('button', { name: 'Se rendre à la filature', exact: true }).click();
  await page.locator('#schedule-time').fill('08:30'); await page.getByRole('button', { name: 'Inscrire à l’agenda', exact: true }).click();
  for (let i = 0; i < 3; i++) await page.getByRole('button', { name: 'Aller à la prochaine échéance', exact: true }).click();
  await population(page); await page.getByRole('button', { name: 'Distinguer un contact du collectif', exact: true }).click();
  await page.getByRole('button', { name: 'Donner 6 pains au collectif', exact: true }).click();
  await nav(page, 'Affaires'); await page.getByRole('button', { name: 'Planifier une fournée', exact: true }).click();
  await page.locator('#schedule-time').fill('23:50'); await page.getByRole('button', { name: 'Inscrire à l’agenda', exact: true }).click();
  const j1 = await saved(page, 2); assert.equal(j1.version, 2);
  assert.equal(Object.keys(j1.state.world.population.named).length, 2); assert.equal(j1.state.world.population.groups['group-fileurs'].count, 23);
  assert.ok(j1.state.agenda.length); assert.ok(j1.state.knowledge.entries.length); assert.ok(j1.state.events.length);
  await writeFile(path.join(report, 'actual-j1-save.json'), JSON.stringify(j1, null, 2));
  await stop(); await access(path.join(profile, 'Local Storage', 'leveldb'));
  await record('Actual J1 0.2.0 Portable created v2 save with contact, bread donation, conflict, knowledge and agenda');

  const movedDir = path.join(process.env.RUNNER_TEMP, 'DYNASTY autre dossier é'); await mkdir(movedDir, { recursive: true });
  const movedPortable = path.join(movedDir, 'DYNASTY-0.3.2-Windows-x64.exe');
  await copyFile(path.join(desktop, 'dist', path.basename(movedPortable)), movedPortable);
  page = await launch(movedPortable, true);
  await checkAdjustedHud(page, 'Portable 0.3.2');
  const j2 = await saved(page);
  assert.equal(j2.version, 3); assert.equal(j2.state.world.minute, j1.state.world.minute);
  for (const key of ['bakery', 'playerLocation']) assert.deepEqual(j2.state.world[key], j1.state.world[key]);
  assert.deepEqual(j2.state.world.population.named, j1.state.world.population.named);
  assert.equal(j2.state.world.population.groups['group-fileurs'].count, 23);
  assert.deepEqual(j2.state.agenda, j1.state.agenda);
  for (const entry of j1.state.knowledge.entries) assert.ok(j2.state.knowledge.entries.some(e => e.id === entry.id && e.title === entry.title));
  for (const event of j1.state.events) assert.ok(j2.state.events.some(e => e.id === event.id && e.at === event.at));
  assert.deepEqual(JSON.parse(await page.evaluate(() => localStorage.getItem('dynasty:auto:v2'))), j1);
  await record('Actual J1 Portable → relocated J2.5 Portable: automatic v2 migration, original v2 retained');
  await stop();
  page = await launch(path.join(desktop, 'dist', 'DYNASTY-0.3.2-Windows-x64.exe'), true);
  await assertSame(page, j2, 'Portable moved to a different folder: complete v3 state unchanged'); await stop();

  const previousInstall = await install(path.join(desktop, 'dist', 'DYNASTY-Setup-0.3.0-x64.exe'));
  assert.equal(previousInstall.DisplayVersion, '0.3.0');
  page = await launch(installedExe);
  await assertSame(page, j2, 'Previous published J2 0.3.0 installer reads the shared v3 conflict save');
  await stop();
  const previousHud = await install(path.join(desktop, 'dist', 'DYNASTY-Setup-0.3.1-x64.exe'));
  assert.equal(previousHud.DisplayVersion, '0.3.1');
  assert.equal(previousHud.RegistryKey, previousInstall.RegistryKey);
  page = await launch(installedExe);
  await assertSame(page, j2, 'Previous published HUD 0.3.1 installer reads the shared v3 conflict save');
  await stop();
  const originalInstall = await install(path.join(desktop, 'dist', 'DYNASTY-Setup-0.3.2-x64.exe'));
  assert.equal(originalInstall.DisplayVersion, '0.3.2');
  assert.equal(originalInstall.RegistryKey, previousInstall.RegistryKey, 'J2 → HUD J2.5 conserve l’identité NSIS');
  assert.ok(await verifySignature(['CN=Test Publisher, O=Test Organisation, C=FR'], installedExe), 'Un exécutable non signé ne doit jamais activer les mises à jour');
  await record('Authenticode verifier refuses the unsigned test build on real Windows');
  page = await launch(installedExe);
  await checkAdjustedHud(page, 'Installer 0.3.2');
  await assertSame(page, j2, 'Portable → J2 0.3.0 → HUD 0.3.1 → adjusted HUD 0.3.2: complete conflict save unchanged');
  await expect(page.getByTestId('hud-news')).toBeVisible();
  await expect(page.getByTestId('minimap-player')).toBeVisible();
  await population(page); await page.getByRole('button', { name: 'Proposer un accord complet', exact: true }).click();
  await page.getByRole('button', { name: 'Aller à la prochaine échéance', exact: true }).click();
  await expect(page.getByTestId('movement-knowledge')).toContainText('Accord négocié');
  const resolved = await saved(page);
  await page.screenshot({ path: path.join(report, 'installer-resolved.png') });
  const exported = path.join(report, 'actual-v3-export.json');
  const nativeDownload = path.join(report, 'native-v3-download.json');
  await running.application.evaluate(({ session }, file) => { session.defaultSession.once('will-download', (_event, item) => item.setSavePath(file)); }, nativeDownload);
  await page.getByRole('button', { name: 'Sauvegardes et réglages', exact: true }).click();
  await page.getByRole('button', { name: 'Exporter la partie (.json)', exact: true }).click();
  await expect.poll(async () => { try { return JSON.parse(await readFile(nativeDownload, 'utf8')).version; } catch { return null; } }, { timeout: 15000 }).toBe(3);
  // Playwright owns/removes its tracked DownloadItem on close; preserve an ordinary backup.
  await copyFile(nativeDownload, exported);
  assert.deepEqual(JSON.parse(await readFile(exported, 'utf8')).state, resolved.state);
  await record('Installer native JSON export after negotiated agreement', { stateSHA256: stateDigest(resolved.state) });
  await stop();
  const currentInstall = await install(path.join(desktop, 'dist', 'DYNASTY-Setup-0.4.0-x64.exe'));
  assert.equal(currentInstall.DisplayVersion, '0.4.0');
  assert.equal(currentInstall.RegistryKey, originalInstall.RegistryKey);
  page = await launch(installedExe); currentSaveVersion = 4;
  const migrated = await saved(page);
  assert.equal(migrated.version, 4);
  assert.deepEqual(migrated.state.world, resolved.state.world);
  assert.deepEqual(migrated.state.agenda, resolved.state.agenda);
  assert.deepEqual(migrated.state.events, resolved.state.events);
  assert.deepEqual(migrated.state.knowledge, {...resolved.state.knowledge, missionReports: []});
  assert.deepEqual(migrated.state.logistics.missions, []);
  assert.equal(migrated.state.logistics.initialBread, resolved.state.world.bakery.bread);
  assert.deepEqual(JSON.parse(await page.evaluate(()=>localStorage.getItem('dynasty:auto:v3'))).state, resolved.state);
  await checkAdjustedHud(page, 'Installer J3 0.4.0');
  await record('Published Installer 0.3.2 → Installer 0.4.0: complete v3 state migrated, original retained', { stateSHA256: stateDigest(migrated.state) });
  const transporting = await prepareJ3Mission(page);
  await writeFile(path.join(report,'j3-transporting.json'),JSON.stringify(transporting,null,2));
  await stop();
  page = await launch(path.join(desktop, 'dist', 'DYNASTY-0.4.0-Windows-x64.exe'), true);
  await assertSame(page, {state:transporting}, 'Published Installer → Portable 0.4.0: in-progress mission shared unchanged');
  await stop();
  const upgrade = path.join(desktop, 'dist', 'DYNASTY-Setup-0.4.1-x64.exe');
  const upgradedInstall = await install(upgrade);
  assert.equal(upgradedInstall.DisplayVersion, '0.4.1');
  assert.equal(upgradedInstall.RegistryKey, originalInstall.RegistryKey, 'Même identité applicative après mise à niveau');
  page = await launch(installedExe);
  await assertSame(page, {state:transporting}, 'Published Installer/Portable 0.4.0 → Installer 0.4.1: entire v4 state, mission, cargo and knowledge unchanged');
  await checkResourceLayers(page);
  await record('Installer 0.4.1: general resource layers and bakery stocks verified');
  const beforeJ4=await saved(page);
  await writeFile(path.join(report,'actual-v4-before-j4.json'),JSON.stringify(beforeJ4,null,2));
  await stop();
  const j4Install=await install(path.join(desktop,'dist','DYNASTY-Setup-0.5.0-x64.exe'));
  assert.equal(j4Install.DisplayVersion,'0.5.0');assert.equal(j4Install.RegistryKey,originalInstall.RegistryKey);
  page=await launch(installedExe);currentSaveVersion=5;
  const migratedJ4=await saved(page);
  assert.equal(migratedJ4.version,5);
  for(const key of ['world','logistics','knowledge','events','agenda'])assert.deepEqual(migratedJ4.state[key],beforeJ4.state[key],key);
  assert.deepEqual(JSON.parse(await page.evaluate(()=>localStorage.getItem('dynasty:auto:v4'))),beforeJ4);
  await record('Published Installer 0.4.1 → Installer 0.5.0: v4 mission, cargo, stocks, people, dates and information preserved; original v4 retained');
  await checkResourceLayers(page);

  const delivered = await finishJ3Mission(page);
  const j3Export = path.join(report, 'actual-v5-export.json');
  const nativeJ3Download = path.join(report, 'native-v5-download.json');
  await running.application.evaluate(({session},file)=>{session.defaultSession.once('will-download',(_e,item)=>item.setSavePath(file));},nativeJ3Download);
  await page.getByRole('button',{name:'Sauvegardes et réglages',exact:true}).click();
  await page.getByRole('button',{name:'Exporter la partie (.json)',exact:true}).click();
  await expect.poll(async()=>{try{return JSON.parse(await readFile(nativeJ3Download,'utf8')).version;}catch{return null;}}).toBe(5);
  await copyFile(nativeJ3Download,j3Export);
  assert.deepEqual(JSON.parse(await readFile(j3Export,'utf8')).state,delivered);
  await page.keyboard.press('Escape');
  await page.screenshot({path:path.join(report,'j3-installed-delivery.png')});
  await record('In-progress J3 mission survives manual upgrade, delivers once, reports and exports natively', {stateSHA256:stateDigest(delivered)});
  await stop();page=await launch(installedExe);
  await assertSame(page,{state:delivered},'Installed restart after delivery: complete mission and knowledge unchanged');
  await stop();

  page=await launch(installedExe);
  const j4Carrying=await prepareJ4Communication(page);await stop();page=await launch(installedExe);
  await assertSame(page,{state:j4Carrying},'Installer 0.5.0: actual message and carrier survive restart during transmission');
  const j4Received=await finishJ4Communication(page);await stop();page=await launch(installedExe);
  await assertSame(page,{state:j4Received},'Installer 0.5.0: dated response received exactly once and preserved after restart');
  await page.screenshot({path:path.join(report,'j4-installer-response.png')});
  await writeFile(path.join(report,'j4-installer-save-proof.json'),JSON.stringify({j4Carrying,j4Received},null,2));
  await stop();
  const proto2Install=await install(path.join(desktop,'dist',`DYNASTY-Setup-${version}-x64.exe`));
  assert.equal(proto2Install.DisplayVersion,version);assert.equal(proto2Install.RegistryKey,originalInstall.RegistryKey);
  page=await launch(installedExe);
  await assertSame(page,{state:j4Received},`Published Installer 0.5.0 → ${version}: entire v5 state unchanged`);
  const proto2Transport=await prepareProto2Delivery(page);
  await stop();page=await launch(installedExe);await enterProto2(page);
  assert.deepEqual(await proto2State(page),proto2Transport);
  const proto2Delivered=await finishProto2Delivery(page);
  await page.screenshot({path:path.join(report,'proto2-installer.png')});
  await writeFile(path.join(report,'proto2-installer-save-proof.json'),JSON.stringify({proto2Transport,proto2Delivered},null,2));
  await record('Proto 2 Installer: real transport, restart, unique delivery and delayed local report');
  await stop();
  const fixture = await install(path.join(desktop, 'dist', 'upgrade-fixture', `DYNASTY-Setup-${fixtureVersion}-x64.exe`));
  assert.equal(fixture.DisplayVersion, fixtureVersion); assert.equal(fixture.RegistryKey, originalInstall.RegistryKey);
  page = await launch(installedExe);
  await assertSame(page, {state:j4Received}, `Installer ${version} → ${fixtureVersion} unpublished fixture: J4 state unchanged`);
  await enterProto2(page);assert.deepEqual(await proto2State(page),proto2Delivered);
  await record('Manual NSIS upgrade preserves both Proto 2 and J4 save namespaces');
  await page.goto('dynasty://game/');
  // These are manual NSIS upgrades; they are NOT an end-to-end automatic update test.
  for (const [file, version] of [['v1-travel.json', 1], ['v2-observed.json', 2], [exported, 3], [path.join(report,'actual-v4-before-j4.json'),4], [j3Export, 5]]) {
    const source = version >= 3 ? file : path.join(root, 'prototype', 'web', 'tests', 'fixtures', file);
    const before = JSON.parse(await readFile(source, 'utf8'));
    await page.getByRole('button', { name: 'Sauvegardes et réglages', exact: true }).click();
    await page.locator('#import-file').setInputFiles(source);
    const after = await saved(page);
    assert.equal(after.version, 5); assert.equal(after.state.world.minute, before.state.world.minute);
    assert.deepEqual(after.state.world.bakery, before.state.world.bakery);
    assert.deepEqual(after.state.agenda, before.state.agenda);
    if(version===5)assert.deepEqual(after.state,before.state);
    if(version===4)for(const key of ['world','logistics','knowledge','events','agenda'])assert.deepEqual(after.state[key],before.state[key]);
    if (version === 3) { assert.deepEqual(after.state.world,before.state.world);assert.deepEqual(after.state.events,before.state.events); }
    if (version >= 2) assert.deepEqual(after.state.world.population.named, before.state.world.population.named);
    await record(`Installed application imports v${version}`, { minute: after.state.world.minute });
  }
  await stop();
  const currentPortable = path.join(movedDir,'DYNASTY-0.5.0-Windows-x64.exe');
  await copyFile(path.join(desktop,'dist','DYNASTY-0.5.0-Windows-x64.exe'),currentPortable);
  page = await launch(currentPortable,true);
  await assertSame(page,{state:delivered},'Installer → Portable 0.5.0: shared v5 profile, mission and report preserved');
  await checkAdjustedHud(page,'Portable J4 0.5.0');await checkResourceLayers(page);await stop();
  // Separate disposable profile: exercise the published Portable → J3 migration too,
  // without deleting or rewinding the first profile's v4 progression.
  const portableProfile=path.join(process.env.RUNNER_TEMP,'dynasty-portable-upgrade-profile');
  await assert.rejects(access(path.join(portableProfile,'Local Storage')),/ENOENT/);
  page=await launch(movedPortable,true,portableProfile);
  await page.getByRole('button',{name:'Sauvegardes et réglages',exact:true}).click();
  await page.locator('#import-file').setInputFiles(exported);
  assert.deepEqual((await saved(page,3)).state,resolved.state);await stop();
  page=await launch(path.join(desktop,'dist','DYNASTY-0.4.0-Windows-x64.exe'),true,portableProfile);
  const portableMigrated=await saved(page,4);
  assert.deepEqual(portableMigrated.state,migrated.state);
  assert.deepEqual(JSON.parse(await page.evaluate(()=>localStorage.getItem('dynasty:auto:v3'))).state,resolved.state);
  await record('Published Portable 0.3.2 → relocated Portable 0.4.0: exact same v3 migration as Installer, original retained');
  const portableMission=await prepareJ3Mission(page);await stop();
  page=await launch(path.join(desktop,'dist','DYNASTY-0.4.1-Windows-x64.exe'),true,portableProfile);
  assert.deepEqual((await saved(page,4)).state,portableMission);
  await record('Published Portable 0.4.0 → published Portable 0.4.1: entire v4 in-progress mission unchanged');
  await stop();page=await launch(currentPortable,true,portableProfile);
  const portableJ4=await saved(page,5);
  for(const key of ['world','logistics','knowledge','events','agenda'])assert.deepEqual(portableJ4.state[key],portableMission[key]);
  assert.deepEqual(JSON.parse(await page.evaluate(()=>localStorage.getItem('dynasty:auto:v4'))).state,portableMission);
  await record('Published Portable 0.4.1 → relocated Portable 0.5.0: v5 migration preserves all v4 values and retains original');
  await checkResourceLayers(page); await stop();
  page=await launch(path.join(desktop,'dist','DYNASTY-0.5.0-Windows-x64.exe'),true,portableProfile);
  assert.deepEqual(await j3State(page),portableJ4.state);
  const portableDelivery=await finishJ3Mission(page);
  await writeFile(path.join(report, 'portable-0.4.1-to-0.5.0.json'), JSON.stringify({before:portableMission,after:portableDelivery},null,2));
  await record('Relocated actual Portable resumes cargo, delivers once and receives the dated report',{stateSHA256:stateDigest(portableDelivery)});
  await stop();
  page=await launch(currentPortable,true,portableProfile);
  const portableReply=await prepareJ4Communication(page);await stop();page=await launch(currentPortable,true,portableProfile);
  await assertSame(page,{state:portableReply},'Actual Portable 0.5.0: restart with carrier in transit, complete v5 state preserved');
  const portableReceived=await finishJ4Communication(page);await stop();page=await launch(currentPortable,true,portableProfile);
  await assertSame(page,{state:portableReceived},'Actual Portable 0.5.0: dated response, unique delivery and knowledge survive restart');
  await page.screenshot({path:path.join(report,'j4-portable-response.png')});
  await writeFile(path.join(report,'j4-portable-save-proof.json'),JSON.stringify({portableReply,portableReceived},null,2));
  await stop();
  const proto2Portable=path.join(movedDir,`DYNASTY-${version}-Windows-x64.exe`);
  await copyFile(path.join(desktop,'dist',`DYNASTY-${version}-Windows-x64.exe`),proto2Portable);
  page=await launch(proto2Portable,true,portableProfile);
  await assertSame(page,{state:portableReceived},`Published Portable 0.5.0 → relocated ${version}: v5 state unchanged`);
  const proto2PortableTransport=await prepareProto2Delivery(page);await stop();
  page=await launch(proto2Portable,true,portableProfile);await enterProto2(page);
  assert.deepEqual(await proto2State(page),proto2PortableTransport);
  const proto2PortableDelivered=await finishProto2Delivery(page);await stop();
  page=await launch(proto2Portable,true,portableProfile);await enterProto2(page);
  assert.deepEqual(await proto2State(page),proto2PortableDelivered);
  await page.screenshot({path:path.join(report,'proto2-portable.png')});
  await writeFile(path.join(report,'proto2-portable-save-proof.json'),JSON.stringify({proto2PortableTransport,proto2PortableDelivered},null,2));
  await record('Actual Proto 2 Portable: relocated executable, transport/restart, delayed report and exact second restart');
  await stop();
  page=await launch(proto2Portable,true);await enterProto2(page);
  assert.deepEqual(await proto2State(page),proto2Delivered);
  assert.deepEqual(await page.evaluate(()=>JSON.parse(localStorage.getItem('dynasty:auto:v5')).state),delivered);
  await record('Installer → Portable: both scenario saves preserved in the same default profile and origin');
  await stop();
  assert.deepEqual(evidence.errors, []);
  await record('Distribution scenarios passed; automatic updates remain disabled and not proven end-to-end');
} catch (error) {
  evidence.failure = { message: error.message, stack: error.stack };
  if (running) await running.page.screenshot({ path: path.join(report, 'failure.png') }).catch(() => {});
  throw error;
} finally {
  if (running) await stop().catch(() => {});
  await writeFile(path.join(report, 'results.json'), JSON.stringify(evidence, null, 2));
}
