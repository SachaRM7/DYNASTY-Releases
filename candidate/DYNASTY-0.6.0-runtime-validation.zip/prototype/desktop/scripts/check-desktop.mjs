import { prepareJ4Communication, finishJ4Communication } from '../../web/scripts/j4-journey.mjs';
import { enterProto2, prepareProto2Delivery, finishProto2Delivery, proto2State } from '../../web/scripts/proto2-journey.mjs';
import { checkResourceLayers } from '../../web/scripts/j3-5-hud-journey.mjs';
import assert from 'node:assert/strict';
import { prepareJ3Mission, finishJ3Mission, j3State } from '../../web/scripts/j3-journey.mjs';
import { createRequire } from 'node:module';
import { mkdtemp, mkdir, readFile, rm, writeFile, copyFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const require = createRequire(import.meta.url);
const { _electron, expect } = createRequire(new URL('../../web/package.json', import.meta.url))('@playwright/test');
// A trailing backslash inside Playwright's quoted Windows command line escapes the closing quote.
const desktop = path.resolve(fileURLToPath(new URL('../', import.meta.url)));
const packagedWindows = process.platform === 'win32';
const report = fileURLToPath(new URL('../../../reports/proto2/desktop/', import.meta.url));
const temporary = await mkdtemp(path.join(tmpdir(), 'dynasty-desktop-'));
const profile = path.join(temporary, 'profile');
const exported = path.join(temporary, 'partie.json');
const errors = [];
await mkdir(report, { recursive: true });
let application;
async function launch() {
  const env = { ...process.env };
  delete env.ELECTRON_RUN_AS_NODE;
  application = await _electron.launch({
    executablePath: packagedWindows ? path.join(desktop, 'dist', 'win-unpacked', 'DYNASTY.exe') : require('electron'),
    // Root/headless flags apply only to the Linux validation environment, never to the delivered app.
    args: [...(process.platform === 'linux' ? ['--no-sandbox', '--ozone-platform=headless'] : []),
      '--disable-gpu', ...(packagedWindows ? [] : [desktop]), `--user-data-dir=${profile}`],
    env, timeout: 30000,
  });
  const page = await application.firstWindow();
  page.on('pageerror', e => errors.push(e.message));
  await page.getByRole('navigation').waitFor();
  return page;
}
async function nav(page, name) { await page.getByRole('navigation').getByRole('button', { name, exact: true }).click(); }
async function population(page) {
  await nav(page, 'Carnet');
  await page.getByRole('tab', { name: 'Personnes', exact: true }).click();
  await page.getByRole('button', { name: 'Collectif et contacts', exact: true }).click();
}
try {
  let page = await launch();
  assert.equal(page.url(), 'dynasty://game/');
  await checkResourceLayers(page);
  assert.deepEqual(await page.evaluate(() => [typeof window.require, typeof window.process]), ['undefined', 'undefined']);
  const runtime = await application.evaluate(({ app, BrowserWindow }) => ({
    platform: process.platform, packaged: app.isPackaged, versions: process.versions, profile: app.getPath('userData'),
    preferences: ['sandbox', 'contextIsolation', 'nodeIntegration'].map(key => [key, BrowserWindow.getAllWindows()[0].webContents.getLastWebPreferences()[key]]),
  }));
  assert.equal(runtime.profile, profile);
  if (packagedWindows) assert.equal(runtime.packaged, true);
  assert.deepEqual(runtime.preferences, [['sandbox', true], ['contextIsolation', true], ['nodeIntegration', false]]);
  // Exercise the actual sandboxed preload and save acknowledgement, not only a mock updater.
  const prepare = () => application.evaluate(async ({ BrowserWindow, ipcMain }) => {
    const contents = BrowserWindow.getAllWindows()[0].webContents;
    const nonce = 'desktop-test-save';
    return new Promise(resolve => {
      const timer = setTimeout(() => { ipcMain.removeListener('dynasty:restart-ready', receive); resolve('timeout'); }, 5000);
      function receive(event, reply, saved) {
        if (event.sender === contents && reply === nonce) { clearTimeout(timer); ipcMain.removeListener('dynasty:restart-ready', receive); resolve(saved); }
      }
      ipcMain.on('dynasty:restart-ready', receive);
      contents.send('dynasty:prepare-restart', nonce);
    });
  });
  assert.equal(await prepare(), true);
  await expect(page.getByTestId('clock')).toContainText('EN PAUSE');
  await page.evaluate(() => { window.__originalSetItem = Storage.prototype.setItem; Storage.prototype.setItem = () => { throw new Error('test quota'); }; });
  assert.equal(await prepare(), false);
  await expect(page.getByRole('alert')).toContainText('Redémarrage annulé');
  await page.evaluate(() => { Storage.prototype.setItem = window.__originalSetItem; delete window.__originalSetItem; });
  await nav(page, 'Agenda');
  await page.getByRole('button', { name: 'Avancer de 24 heures', exact: true }).click();
  await expect(page.getByTestId('clock')).toContainText('J2 · 08:00');
  await page.getByRole('button', { name: 'Sauvegardes et réglages', exact: true }).click();
  await page.getByRole('button', { name: 'Diagnostic omniscient du monde', exact: true }).click();
  const event = page.getByTestId('world-journal').locator('article').filter({ has: page.getByRole('heading', { name: 'Arrêt collectif du travail', exact: true }) });
  await expect(event).toContainText('Non reçu par le joueur');
  await event.screenshot({ path: path.join(report, 'evenement-prive.png') });
  await population(page);
  await page.getByRole('button', { name: 'Se rendre à la filature', exact: true }).click();
  await page.locator('#schedule-time').fill('08:30');
  await page.getByRole('button', { name: 'Inscrire à l’agenda', exact: true }).click();
  for (let i = 0; i < 3; i++) await page.getByRole('button', { name: 'Aller à la prochaine échéance', exact: true }).click();
  await population(page);
  await page.getByRole('button', { name: 'Distinguer un contact du collectif', exact: true }).click();
  await expect(page.getByTestId('group-observation')).toContainText('23 anonymes + 2 nommés = 25');
  const people = await page.getByTestId('known-people').textContent();
  await page.getByRole('button', { name: 'Sauvegardes et réglages', exact: true }).click();
  await application.evaluate(({ session }, destination) => {
    session.defaultSession.once('will-download', (_event, item) => item.setSavePath(destination));
  }, exported);
  await page.getByRole('button', { name: 'Exporter la partie (.json)', exact: true }).click();
  await expect.poll(async () => { try { return JSON.parse(await readFile(exported, 'utf8')).version; } catch { return null; } }).toBe(5);
  const saved = JSON.parse(await readFile(exported, 'utf8'));
  // Playwright deletes tracked downloads when closing its Electron context.
  // Keep an ordinary file copy, as a player would, for the subsequent import.
  const backup = `${exported}.backup.json`;
  await copyFile(exported, backup);
  assert.equal(saved.state.world.population.groups['group-fileurs'].count, 23);
  assert.equal(Object.keys(saved.state.world.population.named).length, 2);
  assert.ok(saved.state.knowledge.entries.some(e => e.title === 'La grève, vue de vos propres yeux'));
  await application.close(); application = null;
  page = await launch();
  await expect(page.getByTestId('known-people')).toHaveText(people);
  await expect(page.getByTestId('clock')).toContainText('J2 · 08:35');
  await expect(page.getByTestId('clock')).toContainText('EN PAUSE');
  await page.getByRole('button', { name: 'Avancer de 24 heures', exact: true }).click();
  await page.getByRole('button', { name: 'Sauvegardes et réglages', exact: true }).click();
  await page.locator('#import-file').setInputFiles(backup);
  await expect(page.getByTestId('clock')).toContainText('J2 · 08:35');
  await expect(page.getByTestId('known-people')).toHaveText(people);
  await page.getByRole('button', { name: 'Proposer un accord complet', exact: true }).click();
  await page.getByRole('button', { name: 'Aller à la prochaine échéance', exact: true }).click();
  await expect(page.getByTestId('clock')).toContainText('J2 · 10:00');
  await expect(page.getByTestId('movement-knowledge')).toContainText('Accord négocié');
  await expect(page.locator('.crowd')).toHaveCount(0);
  await application.close(); application = null;
  page = await launch();
  await expect(page.getByTestId('movement-knowledge')).toContainText('Accord négocié');
  await expect(page.getByTestId('known-people')).toHaveText(people);
  await page.screenshot({ path: path.join(report, 'bureau-reprise.png') });
  const transporting = await prepareJ3Mission(page);
  await application.close(); application = null; page = await launch();
  assert.deepEqual(await j3State(page), transporting, 'Mission et cargaison conservées à la fermeture');
  const delivered = await finishJ3Mission(page);
  await application.close(); application = null; page = await launch();
  assert.deepEqual(await j3State(page), delivered, 'Livraison et compte rendu conservés');
  await page.getByTestId('mission-known').scrollIntoViewIfNeeded();
  await page.screenshot({path:path.join(report,'j3-mission-reprise.png')});
  await writeFile(path.join(report,'j3-save-proof.json'),JSON.stringify({transporting,delivered},null,2));
  console.log('J3 : mission sauvegardée en transport, fermeture et reprise exactes, livraison unique et compte rendu daté, nouvelle fermeture et reprise vérifiées.');
  const carryingReply=await prepareJ4Communication(page);
  await application.close();application=null;page=await launch();
  assert.deepEqual(await j3State(page),carryingReply,'J4 : fermeture/reprise pendant le transport de la réponse');
  const receivedReply=await finishJ4Communication(page);
  await application.close();application=null;page=await launch();
  assert.deepEqual(await j3State(page),receivedReply,'J4 : réponse et connaissances conservées après réception');
  await page.screenshot({path:path.join(report,'j4-reponse-reprise.png')});
  await writeFile(path.join(report,'j4-save-proof.json'),JSON.stringify({carryingReply,receivedReply},null,2));
  console.log('J4 : consigne et trajet de réponse conservés à la fermeture ; réception unique datée et nouvelle reprise exactes.');
  const historicalSave=await j3State(page);
  const proto2Transport=await prepareProto2Delivery(page);
  assert.equal(page.url(),'dynasty://game/?scenario=proto2');
  assert.equal(await prepare(),true,'Le pont de reprise accepte aussi l’entrée Proto 2');
  await application.close();application=null;page=await launch();await enterProto2(page);
  assert.deepEqual(await proto2State(page),proto2Transport);
  const proto2Delivered=await finishProto2Delivery(page);
  const proto2Export=path.join(temporary,'proto2.json');
  await application.evaluate(({session},file)=>{session.defaultSession.once('will-download',(_e,item)=>item.setSavePath(file));},proto2Export);
  await page.getByRole('button',{name:'Sauvegardes et réglages',exact:true}).click();
  await page.getByRole('button',{name:'Exporter la sauvegarde JSON',exact:true}).click();
  await expect.poll(async()=>{try{return JSON.parse(await readFile(proto2Export,'utf8')).format;}catch{return null;}}).toBe('DYNASTY-proto2-save');
  const proto2Backup=`${proto2Export}.backup.json`;await copyFile(proto2Export,proto2Backup);
  await application.close();application=null;page=await launch();await enterProto2(page);
  assert.deepEqual(await proto2State(page),proto2Delivered);
  await page.getByRole('button',{name:'Sauvegardes et réglages',exact:true}).click();
  await page.locator('[data-p2-action="new:etienne"]').click();
  await page.locator('#p2-import').setInputFiles(proto2Backup);
  await expect.poll(()=>proto2State(page)).toEqual(proto2Delivered);
  assert.deepEqual(await j3State(page),historicalSave,'Le changement de scénario ne modifie aucune donnée de partie J4');
  await writeFile(path.join(report,'proto2-save-proof.json'),JSON.stringify({proto2Transport,proto2Delivered},null,2));
  await page.screenshot({path:path.join(report,'proto2-reprise.png')});
  console.log('Proto 2 : entrée sécurisée, transport sauvegardé, fermeture/reprise exacte, remise unique, compte rendu tardif et export/import natif. Sauvegarde J4 inchangée.');
  assert.deepEqual(errors, []);
  await writeFile(path.join(report, 'runtime.json'), JSON.stringify({ ...runtime, profile: '(répertoire temporaire isolé)', errors }, null, 2));
  console.log(`Application Electron ${runtime.platform} : lancement local, 24 h autonomes, secret, observation, individualisation, export JSON natif, fermeture/reprise et import vérifiés. Accord complet J2 et reprise après fermeture vérifiés.`);
  console.log(runtime.platform === 'win32' ? 'Aucune erreur JavaScript. Parcours exécuté sur Windows.' : 'Aucune erreur JavaScript. Ce contrôle ne constitue pas une exécution sur Windows.');
} finally {
  if (application) await application.close();
  await rm(temporary, { recursive: true, force: true });
}
