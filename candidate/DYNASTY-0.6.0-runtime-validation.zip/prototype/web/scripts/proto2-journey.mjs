// Identical, real campaign UI path in Chromium, offline HTML, Electron and Windows.
import assert from 'node:assert/strict';
export const proto2State = page => page.evaluate(async () => {
  let raw=localStorage.getItem('dynasty:proto2:auto:v1');
  if(raw?.startsWith('DYNASTY-proto2-gzip:')){const bytes=Uint8Array.from(atob(raw.slice('DYNASTY-proto2-gzip:'.length)),x=>x.charCodeAt(0));raw=await new Response(new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'))).text();}
  return JSON.parse(raw).state;
});
export async function enterProto2(page) {
  if (!page.url().includes('scenario=proto2')) await page.getByRole('link', {name:'Explorer le Proto 2 · trois quartiers',exact:true}).click();
  await page.getByRole('navigation',{name:'Navigation du Proto 2'}).waitFor();
}
async function dismiss(page){const message=page.getByRole('button',{name:'Fermer le message',exact:true});if(await message.count())await message.click();}
async function choose(page,id){await dismiss(page);await page.keyboard.press('Escape');await page.locator(`.p2-world-svg [data-p2-building="${id}"]`).click();}
async function next(page){await page.getByRole('button',{name:'Prochaine échéance',exact:true}).first().click();}
async function go(page,id){await choose(page,id);await page.getByRole('button',{name:'S’y rendre',exact:true}).click();for(let n=0;n<10&&(await proto2State(page)).playerTrip;n++)await next(page);}
export async function prepareProto2Delivery(page) {
  await enterProto2(page);await page.getByRole('button',{name:'Sauvegardes et réglages',exact:true}).click();
  await page.locator('[data-p2-action="new:etienne"]').click();await page.getByRole('heading',{name:'Étienne Garnier',exact:true}).waitFor();
  await choose(page,'bakery');await page.getByRole('button',{name:'Proposer un mandat à Jules',exact:true}).click();await dismiss(page);
  await page.locator('form[data-p2-form="support"] [name="personId"]').selectOption('courier-garnier');
  await page.getByRole('button',{name:'Préparer un secours',exact:true}).click();await go(page,'home');
  const state=await proto2State(page),t=state.campaign.transports[0];
  assert.equal(t.status,'travelling');assert.equal(t.requestedCargo.bread,6);assert.equal(state.businesses.bakery.stock.bread,44);assert.equal(state.businesses.factory.stock.bread,0);
  assert.equal(Object.values(state.districts).reduce((n,d)=>n+d.mass,0)+Object.values(state.people).length,12000);
  return state;
}
export async function finishProto2Delivery(page) {
  await enterProto2(page);for(let n=0;n<12&&(await proto2State(page)).campaign.transports[0].status!=='delivered';n++)await next(page);
  const distant=await proto2State(page),t=distant.campaign.transports[0];
  assert.equal(t.status,'delivered');assert.equal(distant.businesses.factory.stock.bread,6);assert.ok(!distant.knowledge.information.some(i=>i.eventId===t.resultId));
  await page.getByRole('navigation').getByRole('button',{name:'Logistique',exact:true}).click();assert.match(await page.locator('.p2-panel').innerText(),/Aucun résultat reçu/);
  await go(page,'bakery');await dismiss(page);await page.getByRole('navigation').getByRole('button',{name:'Réseaux et coulisses',exact:true}).click();
  await page.getByRole('tab',{name:'Contacts',exact:true}).click();await page.locator('.p2-card').filter({has:page.getByRole('heading',{name:'Jules Fabre',exact:true})}).getByRole('button',{name:'Échanger des nouvelles',exact:true}).click();
  await page.getByRole('tab',{name:'Secrets et renseignements',exact:true}).click();assert.match(await page.locator('.p2-panel').innerText(),/La mission et le retour sont achevés/);
  const state=await proto2State(page),result=state.campaign.transports[0].resultId,reports=state.knowledge.information.filter(i=>i.eventId===result);
  assert.equal(reports.length,1);assert.ok(reports[0].receivedAt>reports[0].eventAt);assert.equal(state.events.filter(e=>e.id===result).length,1);assert.equal(state.businesses.factory.stock.bread,6);return state;
}
