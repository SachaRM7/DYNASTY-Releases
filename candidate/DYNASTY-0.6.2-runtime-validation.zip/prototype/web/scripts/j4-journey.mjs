// Parcours UI partagé : navigateur, HTML autonome, Electron et vrais EXE Windows.
import assert from 'node:assert/strict';
import { prepareJ3Mission, j3State } from './j3-journey.mjs';
export const j4State=j3State;
export async function openContacts(page) {
  await page.getByRole('navigation').getByRole('button',{name:'Relations',exact:true}).click();
  await page.getByRole('button',{name:'Collectif et contacts',exact:true}).click();
}
export async function prepareJ4Communication(page) {
  await prepareJ3Mission(page);
  await page.getByRole('button',{name:'Demander des nouvelles à Jules Fabre',exact:true}).click();
  assert.match(await page.getByTestId('message-known').innerText(),/Aucune réponse reçue/);
  await page.getByRole('button',{name:'Centrer la carte sur Foyer Garnier',exact:true}).click();
  await page.locator('[data-action="context:visit"]').click();
  await page.locator('#schedule-time').fill('08:25');
  await page.getByRole('button',{name:'Inscrire à l’agenda',exact:true}).click();
  for(let i=0;i<3;i++)await page.getByRole('button',{name:'Aller à la prochaine échéance',exact:true}).click();
  await openContacts(page);
  await page.getByRole('button',{name:'Avancer de 15 minutes',exact:true}).click();
  const state=await j4State(page),m=state.autonomy.messages[0];
  assert.equal(state.schema,5);assert.equal(m.status,'carrying');assert.equal(m.learnedAt,null);
  assert.equal(state.logistics.actors.jules.trip.to,'home');
  assert.equal(state.logistics.missions[0].delivered,6);
  assert.match(await page.getByTestId('message-known').innerText(),/Aucune réponse reçue/);
  assert.match(await page.getByTestId('mission-known').innerText(),/remis : 0/);
  return state;
}
export async function finishJ4Communication(page) {
  await openContacts(page);
  await page.getByRole('button',{name:'Avancer de 15 minutes',exact:true}).click();
  const state=await j4State(page),m=state.autonomy.messages[0];
  assert.ok(m.learnedAt>m.responseAt);assert.equal(m.receivedAt,523);
  const report=state.knowledge.missionReports.find(r=>r.channel==='report'&&r.delivered===6);
  assert.equal(report.eventAt,523);assert.equal(report.learnedAt,m.learnedAt);
  assert.equal(state.events.filter(e=>e.kind==='mission-delivery').length,1);
  assert.equal(state.events.filter(e=>e.kind==='message-information').length,1);
  assert.equal(state.world.bakery.bread,30);assert.equal(state.logistics.distributed['group-fileurs'],6);
  assert.match(await page.getByTestId('message-known').innerText(),/Réponse reçue/);
  assert.match(await page.getByTestId('mission-known').innerText(),/remis : 6/);
  return state;
}
