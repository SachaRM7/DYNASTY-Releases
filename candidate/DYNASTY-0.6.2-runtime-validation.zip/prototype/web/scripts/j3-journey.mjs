// Shared UI journey for the standalone HTML and the real packaged Windows app.
import assert from 'node:assert/strict';
export const j3State = page => page.evaluate(() => JSON.parse(localStorage.getItem('dynasty:auto:v5') ?? localStorage.getItem('dynasty:auto:v4')).state);
async function population(page) {
  await page.getByRole('navigation').getByRole('button',{name:'Relations',exact:true}).click();
  await page.getByRole('button',{name:'Collectif et contacts',exact:true}).click();
}
export async function prepareJ3Mission(page) {
  await page.getByRole('button',{name:'Sauvegardes et réglages',exact:true}).click();
  await page.getByRole('button',{name:'Nouvelle partie laboratoire',exact:true}).click();
  await page.getByRole('button',{name:'Recommencer à 08 h',exact:true}).click();
  await population(page);
  await page.getByRole('button',{name:'Proposer un mandat à Jules Fabre',exact:true}).click();
  await page.getByRole('button',{name:'Préparer la livraison avec Jules Fabre',exact:true}).click();
  await page.getByRole('button',{name:'Proposer cette mission',exact:true}).click();
  await page.getByRole('button',{name:'Avancer de 15 minutes',exact:true}).click();
  const s=await j3State(page);
  assert.equal(s.logistics.missions[0].status,'outbound');
  assert.equal(s.logistics.missions[0].cargo,6);assert.equal(s.logistics.missions[0].delivered,0);
  assert.equal(s.world.bakery.bread,30);assert.ok(s.logistics.actors.jules.trip);
  return s;
}
export async function finishJ3Mission(page) {
  await population(page);
  for(let i=0;i<3;i++)await page.getByRole('button',{name:'Avancer de 15 minutes',exact:true}).click();
  await page.getByRole('button',{name:'Écouter le compte rendu de Jules Fabre',exact:true}).click();
  const s=await j3State(page),m=s.logistics.missions[0];
  assert.equal(m.status,'completed');assert.equal(m.pickedUp,6);assert.equal(m.delivered,6);assert.equal(m.cargo,0);
  assert.equal(s.world.bakery.bread,30);assert.equal(s.logistics.distributed['group-fileurs'],6);
  assert.equal(s.events.filter(e=>e.kind==='mission-delivery').length,1);
  assert.ok(s.knowledge.missionReports.some(r=>r.channel==='report'&&r.eventAt===523&&r.learnedAt===540&&r.delivered===6));
  await page.getByTestId('mission-known').scrollIntoViewIfNeeded();
  return s;
}
