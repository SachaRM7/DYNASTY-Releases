// Shared real-UI assertions for the offline HTML and both Windows distributions.
import assert from 'node:assert/strict';
export async function checkResourceLayers(page) {
  const saves = () => page.evaluate(() => Object.fromEntries(Object.entries(localStorage).filter(([k]) => /^dynasty:(legacy:)?auto:v[1-5]$/.test(k)).map(([k,v]) => [k, JSON.parse(v).state])));
  await page.getByRole('navigation').getByRole('button',{name:'Quartier',exact:true}).click();
  const before = await saves();
  assert.deepEqual(await page.locator('.hud-resources small').allTextContents(), ['Argent', 'Capacité organisationnelle', 'Lignée', 'Notoriété']);
  assert.equal(await page.locator('.hud-resources [data-testid="bread"], .hud-resources [data-testid="flour"]').count(), 0);
  for (const label of ['Capacité organisationnelle', 'Lignée', 'Notoriété']) {
    const indicator = page.getByRole('group', {name:`${label} : —`,exact:true});
    await indicator.focus();
    const hint = page.getByRole('tooltip').filter({hasText:'Mécanique non encore simulée'});
    await hint.waitFor({state:'visible'});
    await page.keyboard.press('Enter');
  }
  const cash = await page.getByTestId('cash').innerText();
  await page.getByRole('navigation').getByRole('button',{name:'Ressources',exact:true}).click();
  assert.equal(await page.getByTestId('bakery-cash').innerText(), cash);
  assert.match(await page.getByTestId('bread').innerText(), /^\d+ pains$/);
  assert.match(await page.getByTestId('flour').innerText(), /^\d+ kg$/);
  assert.deepEqual(await saves(), before, 'Lire les ressources ne modifie aucun solde ni la partie');
  console.log('J3.5 : quatre repères, trois mécaniques non chiffrées, stocks dans la boulangerie, même solde et partie inchangée.');
}
