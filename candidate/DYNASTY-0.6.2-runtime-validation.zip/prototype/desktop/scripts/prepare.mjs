import { mkdir, copyFile } from 'node:fs/promises';

await mkdir(new URL('../app/', import.meta.url), { recursive: true });
await copyFile(new URL('../../web/dist/DYNASTY.html', import.meta.url), new URL('../app/DYNASTY.html', import.meta.url));
console.log('HTML Proto 2 + laboratoire historique copié dans le paquet de bureau ; même origine et même profil de sauvegarde.');
