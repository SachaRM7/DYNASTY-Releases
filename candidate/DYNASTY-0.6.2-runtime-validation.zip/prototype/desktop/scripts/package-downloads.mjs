import { mkdir, readFile, copyFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const desktop = fileURLToPath(new URL('../', import.meta.url));
const { version } = JSON.parse(await readFile(path.join(desktop, 'package.json'), 'utf8'));
const files = { portable: `DYNASTY-${version}-Windows-x64.exe`, installer: `DYNASTY-Setup-${version}-x64.exe` };
const hashes = [];
for (const [kind, name] of Object.entries(files)) {
  const folder = path.join(desktop, 'dist', 'downloads', kind);
  await mkdir(folder, { recursive: true });
  const bytes = await readFile(path.join(desktop, 'dist', name));
  const checksum = `${createHash('sha256').update(bytes).digest('hex')}  ${name}`;
  hashes.push(checksum);
  await copyFile(path.join(desktop, 'dist', name), path.join(folder, name));
  await writeFile(path.join(folder, 'SHA256SUMS.txt'), `${checksum}\n`);
  await writeFile(path.join(folder, 'LIRE-MOI.txt'), `DYNASTY Proto 2 ${version} — Windows 10/11 x64\n\nCette archive contient la version ${kind === 'portable' ? 'PORTABLE' : 'INSTALLER NSIS'}.\nExtraire le ZIP, puis ouvrir ${name}.\n\nPortable : aucun installateur. Déplacer ou remplacer ce fichier ne déplace pas les parties.\nInstaller : installation pour votre utilisateur, raccourci DYNASTY dans le menu Démarrer.\nPour mettre à niveau : fermer DYNASTY puis lancer le nouvel installateur, sans désinstaller.\nAucun Node.js ni terminal nécessaire pour jouer.\n\nLes deux versions partagent %APPDATA%\\DYNASTY-Prototype et l'origine dynasty://game/.\nNe pas effacer ce dossier. Une seule instance peut ouvrir ce profil.\nAvant tout changement : Sauvegardes et réglages → Exporter la partie (.json).\nJ4 lit v1/v2/v3/v4/v5 et écrit v5. Les versions avant 0.5.0 ne lisent pas v5 ; conserver vos anciens exports avant tout retour en arrière.\nLe navigateur web conserve un stockage séparé : utiliser l'export/import JSON.\n\nBuild de test non signé ; Windows peut demander de confirmer son ouverture.\nMises à jour automatiques PRÉPARÉES MAIS DÉSACTIVÉES : pas de source publique signée configurée.\nNe jamais ajouter un jeton GitHub dans l'application. Mise à niveau manuelle disponible.\nLes sommes SHA-256 détectent une corruption ; elles ne remplacent pas une signature d'éditeur.\n\nSource : ${process.env.DYNASTY_SOURCE_SHA ?? process.env.GITHUB_SHA ?? 'construction locale'}\nArtefacts GitHub Actions privés : connexion requise, conservation 14 jours.\nOuvrir le Proto 2 via « Explorer le Proto 2 · trois quartiers » en bas à droite. Campagne 1850–1855 : Étienne, Louis, Rose ou Ravel. Trois quartiers, activités, grèves, filières, enquêtes, organisations et successions. Les valeurs sont celles du laboratoire, à éprouver en jouant.\nLe laboratoire J1–J4 reste accessible. Le Proto 2 écrit son format JSON v2 et relit le format v1 de la première tranche. Il possède son propre format JSON et ne convertit pas les anciennes parties 1852. Exporter chaque scénario séparément.\n`);
}
await writeFile(path.join(desktop, 'dist', 'SHA256SUMS.txt'), `${hashes.join('\n')}\n`);
console.log(hashes.join('\n'));
