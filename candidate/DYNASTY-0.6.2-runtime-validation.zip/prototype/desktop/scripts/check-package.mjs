import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { readFile, mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const require = createRequire(import.meta.url);
const asar = require('@electron/asar');
const desktop = fileURLToPath(new URL('../', import.meta.url));
const archive = path.join(desktop, 'dist', 'win-unpacked', 'resources', 'app.asar');
const files = asar.listPackage(archive);
for (const tool of ['vitest', 'tinypool', 'electron-builder', 'playwright', 'vite', 'typescript']) {
  assert.ok(!files.some(file => file.replaceAll('\\', '/').includes(`/node_modules/${tool}/`)), `${tool} doit rester hors du paquet livré`);
}
const config = JSON.parse(asar.extractFile(archive, 'update-config.json').toString());
assert.equal(config.enabled, false); assert.equal(config.url, ''); assert.deepEqual(config.publisherName, []);
// @electron/asar traverses directories using path.sep, including on Windows.
assert.equal(JSON.parse(asar.extractFile(archive, path.join('node_modules', 'electron-updater', 'package.json')).toString()).version, '6.8.11');
assert.deepEqual(asar.extractFile(archive, path.join('app', 'DYNASTY.html')), await readFile(path.join(desktop, '..', 'web', 'dist', 'DYNASTY.html')));
const report = fileURLToPath(new URL('../../../reports/proto2/', import.meta.url));
await mkdir(report, { recursive: true });
await writeFile(path.join(report, 'package-content.json'), JSON.stringify({ fileCount: files.length, updater: '6.8.11', developmentToolsAbsent: true, bundledHTMLMatchesBuild: true, updates: config }, null, 2));
console.log('Paquet vérifié : HTML identique au build, electron-updater inclus, outils de développement exclus, mises à jour désactivées sans jeton ni URL.');
