const { app, BrowserWindow, Menu, protocol, session, dialog, ipcMain } = require('electron');
const { readFile } = require('node:fs/promises');
const { mkdirSync, existsSync } = require('node:fs');
const { createHash, randomUUID } = require('node:crypto');
const path = require('node:path');
const { createUpdateController } = require('./updater.cjs');

const ENTRY = 'dynasty://game/';
// Same origin and profile, only explicitly shipped scenario entry points.
const LOCAL_ENTRIES = new Set([ENTRY, `${ENTRY}?scenario=proto2`, `${ENTRY}?scenario=living`, `${ENTRY}?scenario=legacy`]);
app.setName('DYNASTY');
// Stable even when the portable executable extracts into a different temporary directory.
// The standard switch also lets the desktop test use its own disposable profile.
const profile = app.commandLine.getSwitchValue('user-data-dir') || path.join(app.getPath('appData'), 'DYNASTY-Prototype');
mkdirSync(profile, { recursive: true });
app.setPath('userData', profile);
protocol.registerSchemesAsPrivileged([
  { scheme: 'dynasty', privileges: { standard: true, secure: true, supportFetchAPI: true } },
]);

let window;
async function prepareRestart() {
  const nonce = randomUUID();
  return new Promise(resolve => {
    const finish = saved => { clearTimeout(timer); ipcMain.removeListener('dynasty:restart-ready', receive); resolve(saved); };
    const receive = (event, replyNonce, saved) => {
      if (event.sender !== window.webContents || event.senderFrame !== window.webContents.mainFrame || !LOCAL_ENTRIES.has(event.senderFrame.url) || replyNonce !== nonce) return;
      if (saved === true) session.defaultSession.flushStorageData();
      finish(saved === true);
    };
    const timer = setTimeout(() => finish(false), 10000);
    ipcMain.on('dynasty:restart-ready', receive);
    window.webContents.send('dynasty:prepare-restart', nonce);
  });
}
function installUpdateMenu() {
  const controller = createUpdateController({
    config: require('./update-config.json'), configPath: path.join(__dirname, 'update-config.json'),
    runtime: { packaged: app.isPackaged, platform: process.platform, executable: process.execPath,
      portable: Boolean(process.env.PORTABLE_EXECUTABLE_FILE),
      installed: existsSync(path.join(path.dirname(process.execPath), 'Uninstall DYNASTY.exe')) },
    makeUpdater: options => new (require('electron-updater').NsisUpdater)(options),
    confirm: async (title, message, action) => (await dialog.showMessageBox(window, {
      type: 'question', title, message, buttons: ['Plus tard', action], defaultId: 0, cancelId: 0,
    })).response === 1,
    inform: async (title, message) => { await dialog.showMessageBox(window, { type: 'info', title, message }); },
    prepareRestart,
  });
  Menu.setApplicationMenu(Menu.buildFromTemplate([{ label: 'DYNASTY', submenu: [
    { label: 'Vérifier les mises à jour…', click: () => controller.check() },
    { type: 'separator' }, { role: 'quit', label: 'Quitter' },
  ] }]));
  if (controller.enabled) void controller.check({ automatic: true });
}
async function openGame() {
  const html = await readFile(path.join(__dirname, 'app', 'DYNASTY.html'), 'utf8');
  const script = html.match(/<script type="module">([\s\S]*?)<\/script>/)?.[1];
  if (!script) throw new Error('Le fichier du jeu est incomplet. Reconstruisez le prototype.');
  const hash = createHash('sha256').update(script).digest('base64');
  protocol.handle('dynasty', request => LOCAL_ENTRIES.has(request.url)
    ? new Response(html, { headers: {
      'Content-Type': 'text/html; charset=utf-8',
      'Content-Security-Policy': `default-src 'none'; script-src 'sha256-${hash}'; style-src 'unsafe-inline'; img-src data: blob:; connect-src 'none'; object-src 'none'; base-uri 'none'; form-action 'none'`,
    } }) : new Response('Introuvable', { status: 404 }));

  const local = session.defaultSession;
  local.setPermissionRequestHandler((_contents, _permission, respond) => respond(false));
  local.setPermissionCheckHandler(() => false);
  local.webRequest.onBeforeRequest({ urls: ['http://*/*', 'https://*/*'] }, (_details, respond) => respond({ cancel: true }));
  local.on('will-download', (event, item) => {
    if (!item.getURL().startsWith('blob:dynasty://game/')) { event.preventDefault(); return; }
    item.setSaveDialogOptions({
      title: 'Exporter la partie DYNASTY',
      defaultPath: path.join(app.getPath('documents'), path.basename(item.getFilename())),
      filters: [{ name: 'Sauvegarde DYNASTY', extensions: ['json'] }],
    });
  });

  window = new BrowserWindow({
    title: 'DYNASTY · Proto 2 et laboratoire J4', width: 1440, height: 900,
    minWidth: 1100, minHeight: 720, backgroundColor: '#1d302b', show: false,
    webPreferences: { nodeIntegration: false, contextIsolation: true, sandbox: true, preload: path.join(__dirname, 'preload.cjs') },
  });
  window.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  window.webContents.on('will-navigate', (event, url) => { if (!LOCAL_ENTRIES.has(url)) event.preventDefault(); });
  window.once('ready-to-show', () => window.show());
  await window.loadURL(ENTRY);
  installUpdateMenu();
}

if (!app.requestSingleInstanceLock()) app.quit();
else {
  app.on('second-instance', () => {
    if (window) { if (window.isMinimized()) window.restore(); window.show(); window.focus(); }
  });
  app.whenReady().then(openGame).catch(error => {
    dialog.showErrorBox('DYNASTY — démarrage impossible', error.message);
    app.quit();
  });
  app.on('window-all-closed', () => app.quit());
  app.on('before-quit', () => { session.defaultSession.flushStorageData(); });
}
