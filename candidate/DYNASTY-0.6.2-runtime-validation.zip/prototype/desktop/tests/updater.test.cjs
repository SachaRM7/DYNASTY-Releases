const { test } = require('node:test');
const assert = require('node:assert/strict');
const { EventEmitter } = require('node:events');
const { disabledReason, createUpdateController } = require('../updater.cjs');

const config = { enabled: true, provider: 'generic', url: 'https://downloads.example.org/dynasty/', publisherName: ['CN=Test Publisher, O=Test Organisation, C=FR'] };
const runtime = { packaged: true, platform: 'win32', portable: false, installed: true, executable: 'C:\\Programs\\DYNASTY.exe' };
function harness(options = {}) {
  const calls = [], notices = [];
  const updater = Object.assign(new EventEmitter(), {
    checkForUpdates: async () => { calls.push('check'); return { isUpdateAvailable: true, updateInfo: { version: '0.3.1' } }; },
    downloadUpdate: async () => { calls.push('download'); },
    quitAndInstall: (...args) => { calls.push(['install', ...args]); },
  }, options.updater);
  const answers = [...(options.answers ?? [true, true])];
  const controller = createUpdateController({ config, configPath: '/app/update-config.json', runtime,
    makeUpdater: () => { calls.push('factory'); return updater; }, verify: async () => null,
    confirm: async () => { calls.push('confirm'); return answers.shift() ?? false; },
    inform: async (...args) => { notices.push(args); },
    prepareRestart: async () => { calls.push('save'); return true; }, ...options,
  });
  return { controller, calls, notices, updater };
}

test('portable, development, unsigned default and non-installed copies never initialize a network updater', async () => {
  for (const options of [{ runtime: { ...runtime, portable: true } }, { runtime: { ...runtime, packaged: false } }, { runtime: { ...runtime, installed: false } }, { config: require('../update-config.json') }]) {
    const h = harness(options);
    await h.controller.check({ automatic: true });
    assert.deepEqual(h.calls, []); assert.deepEqual(h.notices, []);
    await h.controller.check(); assert.equal(h.notices.length, 1);
  }
});
test('feed rejects HTTP, credentials, query tokens, fragments, private provider and missing signing identity', () => {
  for (const bad of [{ url: 'http://example.org/' }, { url: 'https://token@example.org/' }, { url: 'https://example.org/?token=x' }, { url: 'https://example.org/#secret' }, { provider: 'github' }, { publisherName: [] }, { publisherName: ['Test Publisher'] }]) {
    assert.ok(disabledReason({ ...config, ...bad }, runtime));
  }
  assert.equal(disabledReason(config, runtime), null);
});
test('invalid current signature refuses even the first network check', async () => {
  const h = harness({ verify: async () => 'Signature invalide' });
  await h.controller.check(); assert.deepEqual(h.calls, []); assert.match(h.notices[0][1], /Signature invalide/);
});
test('download and restart require separate confirmations, with save before installation', async () => {
  const h = harness(); await h.controller.check();
  assert.deepEqual(h.calls, ['factory', 'check', 'confirm', 'download', 'confirm', 'save', ['install', true, true]]);
  assert.equal(h.updater.autoDownload, false); assert.equal(h.updater.autoInstallOnAppQuit, false);
  assert.equal(h.updater.allowDowngrade, false); assert.equal(h.updater.allowPrerelease, false);
  assert.equal(typeof h.updater.verifyUpdateCodeSignature, 'function');
  assert.equal(h.updater.updateConfigPath, '/app/update-config.json');
});
test('declining download does not fetch the executable', async () => {
  const h = harness({ answers: [false] }); await h.controller.check();
  assert.deepEqual(h.calls, ['factory', 'check', 'confirm']);
});
test('later restart keeps download without installing on ordinary quit', async () => {
  const h = harness({ answers: [true, false, true] }); await h.controller.check();
  assert.equal(h.updater.autoInstallOnAppQuit, false); assert.ok(!h.calls.includes('save'));
  await h.controller.check();
  assert.equal(h.calls.filter(c => c === 'download').length, 1);
  assert.deepEqual(h.calls.at(-1), ['install', true, true]);
});
test('hash/signature/download error never requests restart or saves', async () => {
  const h = harness({ updater: { downloadUpdate: async () => { throw new Error('SHA-512 mismatch'); } } });
  await h.controller.check(); assert.ok(!h.calls.includes('save')); assert.equal(h.calls.filter(c => c === 'confirm').length, 1);
  assert.match(h.notices[0][1], /SHA-512/);
});
test('failed save refuses restart and keeps downloaded update retryable', async () => {
  const h = harness({ prepareRestart: async () => false }); await h.controller.check();
  assert.ok(!h.calls.some(Array.isArray)); assert.match(h.notices[0][1], /sauvegarde/);
});
test('concurrent checks do not duplicate dialogs or installations', async () => {
  const h = harness(); await Promise.all([h.controller.check(), h.controller.check(), h.controller.check()]);
  assert.equal(h.calls.filter(c => c === 'check').length, 1); assert.equal(h.calls.filter(Array.isArray).length, 1);
});
test('no newer release produces no download or restart', async () => {
  const h = harness({ updater: { checkForUpdates: async () => ({ isUpdateAvailable: false }) } });
  await h.controller.check(); assert.deepEqual(h.calls, ['factory']); assert.equal(h.notices.length, 1);
});
