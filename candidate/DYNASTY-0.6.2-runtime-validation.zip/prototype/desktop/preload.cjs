const { contextBridge, ipcRenderer } = require('electron');

// One fixed operation, no filesystem, generic IPC, URLs or Node APIs exposed.
contextBridge.exposeInMainWorld('dynastyDesktop', Object.freeze({
  onPrepareRestart(callback) {
    ipcRenderer.on('dynasty:prepare-restart', async (_event, nonce) => {
      let saved = false;
      try { saved = (await callback()) === true; } catch { /* Refuse restart on failure. */ }
      ipcRenderer.send('dynasty:restart-ready', nonce, saved);
    });
  },
}));
