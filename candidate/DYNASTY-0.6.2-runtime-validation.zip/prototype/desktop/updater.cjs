const { execFile } = require('node:child_process');
const { promisify } = require('node:util');
const path = require('node:path');

// The feed and publisher identity are build-time configuration, never renderer input.
function disabledReason(config, runtime) {
  if (runtime.portable) return 'Version Portable : remplacez le fichier .exe pour changer de version. Vos parties restent dans %APPDATA%\\DYNASTY-Prototype.';
  if (!runtime.packaged || runtime.platform !== 'win32' || !runtime.installed) return 'Les mises à jour concernent uniquement la version Windows installée avec NSIS.';
  if (!config.enabled) return 'Mises à jour préparées, mais désactivées : une source HTTPS publique et une signature Windows doivent encore être configurées et testées. Installez manuellement la prochaine version pour conserver votre progression.';
  try {
    const url = new URL(config.url);
    if (config.provider !== 'generic' || url.protocol !== 'https:' || url.username || url.password || url.search || url.hash) throw new Error();
  } catch { return 'Source de mise à jour invalide : HTTPS public, sans identifiant ni jeton, requis.'; }
  if (!Array.isArray(config.publisherName) || !config.publisherName.length || config.publisherName.some(name => typeof name !== 'string' || !name.startsWith('CN=') || !name.includes(','))) return 'Identité complète du certificat Windows manquante.';
  return null;
}

// Fail closed: a missing, invalid or uncheckable Authenticode signature is an error.
// Compare the full certificate subject, not a partial publisher-name match.
async function verifySignature(publishers, file) {
  const quoted = file.replace(/'/g, "''");
  const script = `$ErrorActionPreference='Stop'; $s=Get-AuthenticodeSignature -LiteralPath '${quoted}'; @{status=$s.Status.ToString();subject=$s.SignerCertificate.Subject} | ConvertTo-Json -Compress`;
  try {
    const powershell = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe');
    const { stdout } = await promisify(execFile)(powershell, ['-NoProfile', '-NonInteractive', '-EncodedCommand', Buffer.from(script, 'utf16le').toString('base64')], { timeout: 30000, windowsHide: true });
    const signature = JSON.parse(stdout.replace(/^\uFEFF/, ''));
    return signature.status === 'Valid' && publishers.includes(signature.subject) ? null : 'Signature Windows invalide ou éditeur différent.';
  } catch { return 'Impossible de vérifier la signature Windows. Installation automatique refusée.'; }
}

function createUpdateController({ config, configPath, runtime, makeUpdater, verify = verifySignature, confirm, inform, prepareRestart }) {
  const reason = disabledReason(config, runtime);
  let updater, busy = false, downloaded = false;
  async function restart() {
    if (!await confirm('Mise à jour prête', 'Redémarrer DYNASTY pour installer la mise à jour ? La partie sera mise en pause et sauvegardée.', 'Sauvegarder et redémarrer')) return;
    if (!await prepareRestart()) throw new Error('La sauvegarde n’a pas pu être confirmée. Exportez votre partie ; aucun redémarrage n’a été lancé.');
    updater.quitAndInstall(true, true);
  }
  async function check({ automatic = false } = {}) {
    if (busy) return;
    if (reason) { if (!automatic) await inform('Mises à jour', reason); return; }
    busy = true;
    try {
      if (!updater) {
        const error = await verify(config.publisherName, runtime.executable);
        if (error) throw new Error(error);
        updater = makeUpdater({ provider: 'generic', url: config.url });
        updater.updateConfigPath = configPath;
        updater.autoDownload = false;
        updater.autoInstallOnAppQuit = false;
        updater.allowPrerelease = false;
        updater.allowDowngrade = false;
        updater.verifyUpdateCodeSignature = verify;
        // Promise rejection is handled below. Avoid an unhandled EventEmitter error.
        updater.on('error', () => {});
      }
      if (downloaded) { await restart(); return; }
      const result = await updater.checkForUpdates();
      if (!result?.isUpdateAvailable) { if (!automatic) await inform('Mises à jour', 'Vous disposez de la dernière version disponible.'); return; }
      if (!await confirm('Nouvelle version disponible', `Télécharger DYNASTY ${result.updateInfo.version} ? Vous pourrez continuer votre partie et choisir quand redémarrer.`, 'Télécharger')) return;
      // electron-updater checks metadata SHA-512 and calls our Authenticode verifier.
      await updater.downloadUpdate();
      downloaded = true;
      await restart();
    } catch (error) {
      await inform('Mise à jour non installée', error.message);
    } finally { busy = false; }
  }
  return { check, enabled: reason === null };
}

module.exports = { disabledReason, verifySignature, createUpdateController };
