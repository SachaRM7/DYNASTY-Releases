const { app, BrowserWindow, Menu, protocol, session, dialog } = require('electron');
const { readFile } = require('node:fs/promises');
const { mkdirSync } = require('node:fs');
const { createHash } = require('node:crypto');
const path = require('node:path');

const ENTRY = 'dynasty://game/';
app.setName('DYNASTY');
// Stable even when the portable executable extracts into a different temporary directory.
// The standard switch also lets the desktop test use its own disposable profile.
const profile = app.commandLine.getSwitchValue('user-data-dir') || path.join(app.getPath('appData'), 'DYNASTY-Prototype');
mkdirSync(profile, { recursive: true });
app.setPath('userData', profile);
protocol.registerSchemesAsPrivileged([
  { scheme: 'dynasty', privileges: { standard: true, secure: true, supportFetchAPI: true } },
]);

let window;
async function openGame() {
  const html = await readFile(path.join(__dirname, 'app', 'DYNASTY.html'), 'utf8');
  const script = html.match(/<script type="module">([\s\S]*?)<\/script>/)?.[1];
  if (!script) throw new Error('Le fichier du jeu est incomplet. Reconstruisez le prototype.');
  const hash = createHash('sha256').update(script).digest('base64');
  protocol.handle('dynasty', request => request.url === ENTRY
    ? new Response(html, { headers: {
      'Content-Type': 'text/html; charset=utf-8',
      'Content-Security-Policy': `default-src 'none'; script-src 'sha256-${hash}'; style-src 'unsafe-inline'; img-src data: blob:; connect-src 'none'; object-src 'none'; base-uri 'none'; form-action 'none'`,
    } }) : new Response('Introuvable', { status: 404 }));

  const local = session.defaultSession;
  local.setPermissionRequestHandler((_contents, _permission, respond) => respond(false));
  local.setPermissionCheckHandler(() => false);
  local.webRequest.onBeforeRequest({ urls: ['http://*/*', 'https://*/*'] }, (_details, respond) => respond({ cancel: true }));
  local.on('will-download', (event, item) => {
    if (!item.getURL().startsWith('blob:dynasty://game/')) { event.preventDefault(); return; }
    item.setSaveDialogOptions({
      title: 'Exporter la partie DYNASTY',
      defaultPath: path.join(app.getPath('documents'), path.basename(item.getFilename())),
      filters: [{ name: 'Sauvegarde DYNASTY', extensions: ['json'] }],
    });
  });

  Menu.setApplicationMenu(null);
  window = new BrowserWindow({
    title: 'DYNASTY · Prototype J1', width: 1440, height: 900,
    minWidth: 1100, minHeight: 720, backgroundColor: '#1d302b', show: false,
    webPreferences: { nodeIntegration: false, contextIsolation: true, sandbox: true },
  });
  window.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  window.webContents.on('will-navigate', event => event.preventDefault());
  window.once('ready-to-show', () => window.show());
  await window.loadURL(ENTRY);
}

if (!app.requestSingleInstanceLock()) app.quit();
else {
  app.on('second-instance', () => {
    if (window) { if (window.isMinimized()) window.restore(); window.show(); window.focus(); }
  });
  app.whenReady().then(openGame).catch(error => {
    dialog.showErrorBox('DYNASTY — démarrage impossible', error.message);
    app.quit();
  });
  app.on('window-all-closed', () => app.quit());
  app.on('before-quit', () => { session.defaultSession.flushStorageData(); });
}
